package dao;

public class RegistrationDao {

}
